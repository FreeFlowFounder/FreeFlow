import PageContainer from "../components/PageContainer";

function ValidatorPanel() {
  return (
    <PageContainer>
    <div style={{ padding: "2rem" }}>
      <h2>Validator Panel</h2>
      <p>This is where users will stake FLW, unstake, and vouch for campaigns.</p>
    </div>
  </PageContainer>
  );
}

export default ValidatorPanel;
